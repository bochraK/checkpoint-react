import React from 'react'
import Table from 'react-bootstrap/Table';

function Tableau() {
  return (
    <Table striped bordered hover style={{width:"70%", marginLeft:"30px"}}>
    <thead>
      <tr>
        <th>#</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Username</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>Wafi</td>
        <td>BenJeddou</td>
        <td>FouFou</td>
      </tr>
      <tr>
        <td>2</td>
        <td>Malek</td>
        <td>benMlouka</td>
        <td>user2</td>
      </tr>
      <tr>
        <td>3</td>
        <td colSpan={2}>Larry the Bird</td>
        <td>@twitter</td>
      </tr>
    </tbody>
  </Table>

  )
}

export default Tableau