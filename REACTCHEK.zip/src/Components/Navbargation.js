import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import x from './x.jpg'

function Navbargation() {
  return (
    <Navbar style={{ display:"flex", justifyContent:"space-around", marginBottom:"80px"}} bg="dark" variant="dark">
    <Container >
    <img style={{ width:"70px"}} alt="gomycode" src={x} />
      <Nav style={{ display:"flex", justifyContent:"space-around" }}>
        <Nav.Link href="#home">Home</Nav.Link>
        <Nav.Link href="#features">About</Nav.Link>
        <Nav.Link href="#pricing">Pricing</Nav.Link>
      </Nav>
    </Container>
  </Navbar>
  )
}

export default Navbargation