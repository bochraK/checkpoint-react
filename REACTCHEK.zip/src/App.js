
import Navbargation from './Components/Navbargation';
import Tableau from './Components/Tableau';
import Formulaire from './Components/Formulaire';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <div >
      <Navbargation />
      <Tableau />
      <Formulaire />
    </div>
  );
}

export default App;
